words = [  # verbs_or_nouns
         'allude', 'muse', 'recoil', 'burrow', 'rein', 'snatch', 'plunge', 'cater', 'wince', 'evade', 'shove',
         'contradict', 'trail off', 'shrunk', 'sear', 'snarl', 'teeter', 'ward', 'peer', 'pry', 'mutter',
         'murmur', 'lurch', 'infringe', 'faze', 'shrink', 'subside', 'tow', 'startle', 'sprawl', 'propel',
         'seethe', 'glee', 'gush', 'waft', 'leap', 'dunk', 'upend', 'fling', 'shed', 'scurry', 'strain',
         'steady', 'tumble', 'evade', 'taint', 'hallow', 'rasp', 'scold', 'resent', 'niggle', 'graze', 'swoop',
         'fuddle', 'bawl', 'slack', 'interrogate', 'hurl', 'induce', 'prevaricate', 'halt', 'stifle', 'swoon',

           # adverbs
         'abruptly', 'hastily', 'ludicrously', 'fierce', 'gingerly', 'askew', 'tantamount',

           # adjectives
         'tedious', 'solute', 'sublime', 'gauzy', 'perpetual', 'frank', 'ghastly', 'sodden', 'wry',
         'morbid', 'tentative', 'obsequious', 'obnoxious', 'despicable', 'skim', 'sluggish', 'skittish',
         'conceited', 'acquainted', 'bilious', 'superb', 'congenial', 'imminent', 'exquisite', 'malleable', 'snug',
         'smug', 'studious', 'murky', 'frantic', 'scarce', 'sodden', 'obscene', 'precarious', 'lucid', 'lurid', 'eerie',

           # nouns
         'cutlery', 'stain', 'pang', 'hush', 'bollocks', 'surmise', 'axiom', 'hedge', 'parlour', 'dickens',
         'nook', 'sack', 'malice', 'midden', 'muddle', 'margin', 'presence', 'trolley', 'petroleum', 'infusion',
         'decanter', 'gilder', 'barley', 'amber', 'heap', 'brandy', 'remedy', 'chap', 'suffocation', 'ottoman', 'lark',
         'mishap', 'rust', 'rower', 'decency', 'inclination', 'lane', 'vivacity', 'tantrum', 'knack', 'twig', 'orchard',
         'dimple', 'pendulum', 'sentience', 'tendril', 'plea', 'seal', 'buggery', 'solicitor', 'rustle', 'nape', 'halo',
         'tinge', 'sod', 'handkerchief', 'brook', 'tumbler', 'fleck', 'vow', 'clamour', 'herald', 'sprig', 'essence',
         'heirloom', 'pendant', 'sorrow', 'resemblance', 'remainder', 'affinity', 'estate', 'palate', 'ewer', 'basin',
         'pallor', 'dent', 'porcelain', 'tincture', 'virtue', 'stale', 'oath', 'ruth', 'edifice', 'hubbub', 'hiccups',
         'decoy', 'tendon', 'kinship', 'treatise', 'errand', 'cellar', 'perch', 'suite', 'cue', 'seesaw', 'dignity',
         'peal', 'beam', 'compartment', 'jaunt']
